import { useEffect } from "react";
import { Star, Heart, Zap, Palette } from "lucide-react";
import { Button } from "@/components/ui/button";

const scrollToSection = (id: string) => {
  const element = document.getElementById(id);
  element?.scrollIntoView({ behavior: "smooth" });
};

export default function Index() {
  useEffect(() => {
    document.title = "Sea - VTuber Artist | Portfolio & Pricing";
  }, []);

  return (
    <div>
      {/* 🔥 Test Div for Tailwind */}
      <div className="bg-gradient-to-b from-purple-900 to-pink-500 text-white p-6 rounded-lg text-center mb-8">
        Gradient Test (Tailwind Check)
      </div>

      {/* Navigation Buttons */}
      <div className="flex flex-col gap-4 sm:flex-row sm:justify-center">
        <Button
          size="lg"
          className="px-8 py-4 text-lg"
          onClick={() => scrollToSection("portfolio")}
        >
          <Palette className="mr-2 size-5" />
          View Portfolio
        </Button>

        <Button
          size="lg"
          variant="outline"
          className="px-8 py-4 text-lg backdrop-blur-sm"
          onClick={() => scrollToSection("pricing")}
        >
          <Star className="mr-2 size-5" />
          See Pricing
        </Button>
      </div>

      {/* Portfolio Section */}
      <section
        id="portfolio"
        className="relative z-10 bg-background/95 py-24 backdrop-blur-sm"
      >
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold">Portfolio</h2>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="relative z-10 py-24">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold">Pricing</h2>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="relative z-10 bg-background/95 py-24 backdrop-blur-sm"
      >
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold">Contact</h2>
        </div>
      </section>
    </div>
  );
}
