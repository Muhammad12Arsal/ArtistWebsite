  // // // "use client";

  // // // import { Star, Heart, Zap, Gem, Palette } from "lucide-react";
  // // // import { Card, CardContent } from "@/components/ui/card";
  // // // import { Button } from "@/components/ui/button";

  // // // export default function Home() {
  // // //   return (
  // // //     <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
  // // //       <div className="flex justify-center mb-6">
  // // //         <img
  // // //           src="/Neonola.png"
  // // //           alt="Profile"
  // // //           className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-white opacity-60"
  // // //         />
  // // //       </div>

  // // //       <div className="text-center px-6 py-20">
  // // //         {/* Badge */}
  // // //         <div className="inline-block bg-white px-4 py-1 rounded-full text-sm font-bold shadow-md mb-6 text-black">
  // // //           Welcome! <Star className="inline-block w-4 h-4 text-yellow-500 ml-1" />
  // // //         </div>

  // // //         {/* Heading */}
  // // //         <h1 className="text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-6">
  // // //           I'm Neonola, <span className="text-gray-900">VTuber Artist</span>
  // // //         </h1>

  // // //         {/* Subtext */}
  // // //         <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
  // // //           Crafting high-quality VTuber models with personality and precision.
  // // //           Let&apos;s bring your ideal character to life in a way that captivates
  // // //           and connects.
  // // //         </p>

  // // //         {/* Buttons */}
  // // //         <div className="flex flex-wrap justify-center gap-4 mb-10">
  // // //           <button className="px-6 py-3 rounded-lg bg-gray-900 text-white font-medium shadow hover:bg-gray-800 transition inline-flex items-center gap-2">
  // // //             <Palette className="w-5 h-5" />
  // // //             View Portfolio
  // // //           </button>

  // // //           <button className="px-6 py-3 rounded-lg bg-white text-gray-900 font-medium shadow hover:bg-gray-100 transition inline-flex items-center gap-2">
  // // //             <Star className="w-5 h-5" />
  // // //             See Pricing
  // // //           </button>
  // // //         </div>

  // // //         {/* Features */}
  // // //         <div className="flex flex-wrap justify-center gap-8 text-white/90 font-medium">
  // // //           <div className="flex items-center gap-2">
  // // //             <Heart className="w-5 h-5 text-pink-200" /> 50+ Happy Clients
  // // //           </div>
  // // //           <div className="flex items-center gap-2">
  // // //             <Zap className="w-5 h-5 text-yellow-200" /> Fast Delivery
  // // //           </div>
  // // //           <div className="flex items-center gap-2">
  // // //             <Gem className="w-5 h-5 text-purple-200" /> Premium Quality
  // // //           </div>
  // // //         </div>
  // // //       </div>

  // // //       {/* Portfolio Section */}
  // // //       <section className="max-w-5xl mx-auto py-20 px-6 text-center">
  // // //         <h2 className="text-3xl font-bold mb-2 text-black">Portfolio Showcase</h2>
  // // //         <p className="text-lg text-gray-700 mb-8">
  // // //           Explore my collection of unique VTuber characters, each crafted with attention to detail and personality
  // // //         </p>

  // // //         {/* === Scrolling "Model Art" patti (single track) === */}
  // // // <div className="marquee w-full border border-black/20 shadow-lg bg-gradient-to-br from-slate-600/70 to-slate-500/70 backdrop-blur-md">
  // // //   <div className="marquee-track py-8 px-8 gap-12 whitespace-nowrap">
  // // //     {/* Block A */}
  // // //     <span className="text-white font-semibold text-lg">
  // // //       Model Art — Custom VTuber model artwork tailored to your style.
  // // //     </span>
  // // //     <span className="text-white/70">•</span>
  // // //     <span className="text-white font-semibold text-lg">
  // // //       High-quality linework • Expressive designs • On-brand palettes
  // // //     </span>
  // // //     <span className="text-white/70">•</span>
  // // //     <span className="text-white font-semibold text-lg">
  // // //       PSD/CLIP files • Ready for Rigging • Clean layers
  // // //     </span>

  // // //     {/* Block B (exact duplicate for seamless loop) */}
  // // //     <span className="text-white font-semibold text-lg">
  // // //       Model Art — Custom VTuber model artwork tailored to your style.
  // // //     </span>
  // // //     <span className="text-white/70">•</span>
  // // //     <span className="text-white font-semibold text-lg">
  // // //       High-quality linework • Expressive designs • On-brand palettes
  // // //     </span>
  // // //     <span className="text-white/70">•</span>
  // // //     <span className="text-white font-semibold text-lg">
  // // //       PSD/CLIP files • Ready for Rigging • Clean layers
  // // //     </span>
  // // //   </div>
  // // // </div>


  // // //         {/* ====== Temporarily disable other cards ====== */}
  // // //         {/*
  // // //         <div className="grid md:grid-cols-3 gap-6 mt-8">
  // // //           <Card>
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-semibold text-lg mb-2">Model Art</h3>
  // // //               <p>Custom VTuber model artwork tailored to your style.</p>
  // // //             </CardContent>
  // // //           </Card>
  // // //           <Card>
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-semibold text-lg mb-2">Rigging</h3>
  // // //               <p>Smooth and expressive Live2D rigging services.</p>
  // // //             </CardContent>
  // // //           </Card>
  // // //           <Card>
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-semibold text-lg mb-2">Timelapse</h3>
  // // //               <p>Watch your VTuber come to life through timelapse videos.</p>
  // // //             </CardContent>
  // // //           </Card>
  // // //         </div>
  // // //         */}
  // // //       </section>

  // // //       {/* Pricing Section */}
  // // //       <section className="bg-gray-50 w-full py-20 px-6 text-center">
  // // //         <h2 className="text-3xl font-bold mb-8">Pricing</h2>
  // // //         <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
  // // //           <Card>
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-bold text-lg mb-2">Basic</h3>
  // // //               <p className="text-2xl font-bold mb-4">$50</p>
  // // //               <ul className="mb-4 space-y-1 text-gray-700">
  // // //                 <li>✅ Simple Model</li>
  // // //                 <li>✅ Flat Colors</li>
  // // //                 <li>✅ 1 Expression</li>
  // // //               </ul>
  // // //               <Button>Order Now</Button>
  // // //             </CardContent>
  // // //           </Card>
  // // //           <Card className="border-2 border-pink-500 shadow-lg">
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-bold text-lg mb-2 text-pink-600">Standard</h3>
  // // //               <p className="text-2xl font-bold mb-4">$150</p>
  // // //               <ul className="mb-4 space-y-1 text-gray-700">
  // // //                 <li>✅ Detailed Model</li>
  // // //                 <li>✅ Shading</li>
  // // //                 <li>✅ 3 Expressions</li>
  // // //               </ul>
  // // //               <Button className="bg-pink-600 text-white hover:bg-pink-700">
  // // //                 Order Now
  // // //               </Button>
  // // //             </CardContent>
  // // //           </Card>
  // // //           <Card>
  // // //             <CardContent className="p-6">
  // // //               <h3 className="font-bold text-lg mb-2">Premium</h3>
  // // //               <p className="text-2xl font-bold mb-4">$300</p>
  // // //               <ul className="mb-4 space-y-1 text-gray-700">
  // // //                 <li>✅ Full Model</li>
  // // //                 <li>✅ Advanced Shading</li>
  // // //                 <li>✅ 5+ Expressions</li>
  // // //               </ul>
  // // //               <Button>Order Now</Button>
  // // //             </CardContent>
  // // //           </Card>
  // // //         </div>
  // // //       </section>

  // // //       {/* Contact Section */}
  // // //       <section className="py-20 px-6 text-center">
  // // //         <h2 className="text-3xl font-bold mb-4">Contact</h2>
  // // //         <p className="mb-6">
  // // //           Ready to bring your VTuber character to life? Let’s work together!
  // // //         </p>
  // // //         <Button className="bg-purple-600 text-white hover:bg-purple-700">
  // // //           Get in Touch
  // // //         </Button>
  // // //       </section>
  // // //     </main>
  // // //   );
  // // // }


  // // "use client";

  // // import { useEffect, useState } from "react";
  // // import { Star, Heart, Zap, Gem, Palette } from "lucide-react";
  // // import { Card, CardContent } from "@/components/ui/card";
  // // import { Button } from "@/components/ui/button";

  // // /* --- Rotating banner: shows one line, switches every 3s --- */
  // // function RotatingBanner() {
  // //   const messages = [
  // //     "Model Art — Custom VTuber model artwork tailored to your style.",
  // //     "High-quality linework • Expressive designs • On-brand palettes",
  // //     "PSD/CLIP files • Ready for Rigging • Clean layers",
  // //   ];
  // //   const [i, setI] = useState(0);

  // //   useEffect(() => {
  // //     const id = setInterval(() => setI((p) => (p + 1) % messages.length), 3000); // 3s
  // //     return () => clearInterval(id);
  // //   }, []);

  // //   return (
  // //     <div className="w-full overflow-hidden rounded-2xl border border-black/20 shadow-lg bg-gradient-to-br from-slate-600/70 to-slate-500/70 backdrop-blur-md">
  // //       <div className="min-h-[64px] flex items-center justify-center px-6 py-4">
  // //         <span key={i} className="ticker-in text-white font-semibold text-lg text-center">
  // //           {messages[i]}
  // //         </span>
  // //       </div>
  // //     </div>
  // //   );
  // // }

  // // export default function Home() {
  // //   return (
  // //     <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
  // //       <div className="flex justify-center mb-6">
  // //         <img
  // //           src="/Neonola.png"
  // //           alt="Profile"
  // //           className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-white opacity-60"
  // //         />
  // //       </div>

  // //       <div className="text-center px-6 py-20">
  // //         {/* Badge */}
  // //         <div className="inline-block bg-white px-4 py-1 rounded-full text-sm font-bold shadow-md mb-6 text-black">
  // //           Welcome! <Star className="inline-block w-4 h-4 text-yellow-500 ml-1" />
  // //         </div>

  // //         {/* Heading */}
  // //         <h1 className="text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-6">
  // //           I'm Neonola, <span className="text-gray-900">VTuber Artist</span>
  // //         </h1>

  // //         {/* Subtext */}
  // //         <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
  // //           Crafting high-quality VTuber models with personality and precision.
  // //           Let&apos;s bring your ideal character to life in a way that captivates
  // //           and connects.
  // //         </p>

  // //         {/* Buttons */}
  // //         <div className="flex flex-wrap justify-center gap-4 mb-10">
  // //           <button className="px-6 py-3 rounded-lg bg-gray-900 text-white font-medium shadow hover:bg-gray-800 transition inline-flex items-center gap-2">
  // //             <Palette className="w-5 h-5" />
  // //             View Portfolio
  // //           </button>

  // //           <button className="px-6 py-3 rounded-lg bg-white text-gray-900 font-medium shadow hover:bg-gray-100 transition inline-flex items-center gap-2">
  // //             <Star className="w-5 h-5" />
  // //             See Pricing
  // //           </button>
  // //         </div>

  // //         {/* Features */}
  // //         <div className="flex flex-wrap justify-center gap-8 text-white/90 font-medium">
  // //           <div className="flex items-center gap-2">
  // //             <Heart className="w-5 h-5 text-pink-200" /> 50+ Happy Clients
  // //           </div>
  // //           <div className="flex items-center gap-2">
  // //             <Zap className="w-5 h-5 text-yellow-200" /> Fast Delivery
  // //           </div>
  // //           <div className="flex items-center gap-2">
  // //             <Gem className="w-5 h-5 text-purple-200" /> Premium Quality
  // //           </div>
  // //         </div>
  // //       </div>

  // //       {/* Portfolio Section */}
  // //       <section className="max-w-5xl mx-auto py-20 px-6 text-center">
  // //         <h2 className="text-3xl font-bold mb-2 text-black">Portfolio Showcase</h2>
  // //         <p className="text-lg text-gray-700 mb-8">
  // //           Explore my collection of unique VTuber characters, each crafted with attention to detail and personality
  // //         </p>

  // //         {/* === Single-line ticker (changes every 3s) === */}
  // //         <RotatingBanner />

  // //         {/* Other cards (commented for now) */}
  // //         {/*
  // //         <div className="grid md:grid-cols-3 gap-6 mt-8">
  // //           <Card>
  // //             <CardContent className="p-6">
  // //               <h3 className="font-semibold text-lg mb-2">Model Art</h3>
  // //               <p>Custom VTuber model artwork tailored to your style.</p>
  // //             </CardContent>
  // //           </Card>
  // //           <Card>
  // //             <CardContent className="p-6">
  // //               <h3 className="font-semibold text-lg mb-2">Rigging</h3>
  // //               <p>Smooth and expressive Live2D rigging services.</p>
  // //             </CardContent>
  // //           </Card>
  // //           <Card>
  // //             <CardContent className="p-6">
  // //               <h3 className="font-semibold text-lg mb-2">Timelapse</h3>
  // //               <p>Watch your VTuber come to life through timelapse videos.</p>
  // //             </CardContent>
  // //           </Card>
  // //         </div>
  // //         */}
  // //       </section>

  // //       {/* Pricing Section */}
  // //       <section className="bg-gray-50 w-full py-20 px-6 text-center">
  // //         <h2 className="text-3xl font-bold mb-8">Pricing</h2>
  // //         <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
  // //           <Card>
  // //             <CardContent className="p-6">
  // //               <h3 className="font-bold text-lg mb-2">Basic</h3>
  // //               <p className="text-2xl font-bold mb-4">$50</p>
  // //               <ul className="mb-4 space-y-1 text-gray-700">
  // //                 <li>✅ Simple Model</li>
  // //                 <li>✅ Flat Colors</li>
  // //                 <li>✅ 1 Expression</li>
  // //               </ul>
  // //               <Button>Order Now</Button>
  // //             </CardContent>
  // //           </Card>
  // //           <Card className="border-2 border-pink-500 shadow-lg">
  // //             <CardContent className="p-6">
  // //               <h3 className="font-bold text-lg mb-2 text-pink-600">Standard</h3>
  // //               <p className="text-2xl font-bold mb-4">$150</p>
  // //               <ul className="mb-4 space-y-1 text-gray-700">
  // //                 <li>✅ Detailed Model</li>
  // //                 <li>✅ Shading</li>
  // //                 <li>✅ 3 Expressions</li>
  // //               </ul>
  // //               <Button className="bg-pink-600 text-white hover:bg-pink-700">
  // //                 Order Now
  // //               </Button>
  // //             </CardContent>
  // //           </Card>
  // //           <Card>
  // //             <CardContent className="p-6">
  // //               <h3 className="font-bold text-lg mb-2">Premium</h3>
  // //               <p className="text-2xl font-bold mb-4">$300</p>
  // //               <ul className="mb-4 space-y-1 text-gray-700">
  // //                 <li>✅ Full Model</li>
  // //                 <li>✅ Advanced Shading</li>
  // //                 <li>✅ 5+ Expressions</li>
  // //               </ul>
  // //               <Button>Order Now</Button>
  // //             </CardContent>
  // //           </Card>
  // //         </div>
  // //       </section>

  // //       {/* Contact Section */}
  // //       <section className="py-20 px-6 text-center">
  // //         <h2 className="text-3xl font-bold mb-4">Contact</h2>
  // //         <p className="mb-6">
  // //           Ready to bring your VTuber character to life? Let’s work together!
  // //         </p>
  // //         <Button className="bg-purple-600 text-white hover:bg-purple-700">
  // //           Get in Touch
  // //         </Button>
  // //       </section>
  // //     </main>
  // //   );
  // // }



  // "use client";

  // import { useEffect, useState } from "react";
  // import { Star, Heart, Zap, Gem, Palette } from "lucide-react";
  // import { Card, CardContent } from "@/components/ui/card";
  // import { Button } from "@/components/ui/button";

  // /* --- Rotating banner: one line, switches every 3s --- */
  // function RotatingBanner() {
  //   const messages = [
  //     "Model Art — Custom VTuber model artwork tailored to your style.",
  //     "High-quality linework • Expressive designs • On-brand palettes",
  //     "PSD/CLIP files • Ready for Rigging • Clean layers",
  //   ];
  //   const [i, setI] = useState(0);

  //   useEffect(() => {
  //     const id = setInterval(() => setI((p) => (p + 1) % messages.length), 2000);
  //     return () => clearInterval(id);
  //   }, []);

  //   return (
  //     <div className="w-full overflow-hidden rounded-2xl border border-black/20 shadow-lg bg-gradient-to-br from-slate-600/70 to-slate-500/70 backdrop-blur-md">
  //       <div className="min-h-[64px] flex items-center justify-center px-6 py-4">
  //         <span key={i} className="ticker-in text-white font-semibold text-lg text-center">
  //           {messages[i]}
  //         </span>
  //       </div>
  //     </div>
  //   );
  // }

  // import Image from "next/image";

  // // 9 image paths (public/models/...)
  // const modelImages = [
  //   "/models/2.jpeg",
  //   "/models/4.jpeg",
  //   "/models/3.jpeg",
  //   "/models/1.png",
  //   "/models/6.jpeg",
  //   "/models/2d.jpg",
  //   // "/models/model7.png",
  //   // "/models/model8.png",
  //   // "/models/model9.png",
  // ];



  // <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
  //   {modelImages.map((src, idx) => (

  //     <div
  //       key={idx}
  //       className="rounded-[22px] bg-white/90 p-2 shadow-md ring-1 ring-black/10"
  //       title={`VTuber model ${idx + 1}`}
  //     >
  //       {/* Important: relative + fixed aspect for fill layout */}
  //       <div className="relative w-full aspect-[3/4] overflow-hidden rounded-[18px] bg-neutral-200/40">
  //         <Image
  //           src={src}
  //           alt={`VTuber model ${idx + 1}`}
  //           fill
  //           sizes="(min-width: 768px) 33vw, 100vw"
  //           className="object-contain"
  //           priority={idx < 3}   // first row loads eagerly
  //         />
  //       </div>
  //     </div>
  //   ))}
  // </div>


  // export default function Home() {
  //   return (
  //     <main className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
  //       <div className="flex justify-center mb-6">
  //         <img
  //           src="/Neonola.png"
  //           alt="Profile"
  //           className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-white opacity-60"
  //         />
  //       </div>

  //       <div className="text-center px-6 py-20">
  //         {/* Badge */}
  //         <div className="inline-block bg-white px-4 py-1 rounded-full text-sm font-bold shadow-md mb-6 text-black">
  //           Welcome! <Star className="inline-block w-4 h-4 text-yellow-500 ml-1" />
  //         </div>

  //         {/* Heading */}
  //         <h1 className="text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-6">
  //           I'm Neonola, <span className="text-gray-900">VTuber Artist</span>
  //         </h1>

  //         {/* Subtext */}
  //         <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
  //           Crafting high-quality VTuber models with personality and precision.
  //           Let&apos;s bring your ideal character to life in a way that captivates
  //           and connects.
  //         </p>

  //         {/* Buttons */}
  //         <div className="flex flex-wrap justify-center gap-4 mb-10">
  //           <button className="px-6 py-3 rounded-lg bg-gray-900 text-white font-medium shadow hover:bg-gray-800 transition inline-flex items-center gap-2">
  //             <Palette className="w-5 h-5" />
  //             View Portfolio
  //           </button>

  //         <button className="px-6 py-3 rounded-lg bg-white text-gray-900 font-medium shadow hover:bg-gray-100 transition inline-flex items-center gap-2">
  //             <Star className="w-5 h-5" />
  //             See Pricing
  //           </button>
  //         </div>

  //         {/* Features */}
  //         <div className="flex flex-wrap justify-center gap-8 text-white/90 font-medium">
  //           <div className="flex items-center gap-2">
  //             <Heart className="w-5 h-5 text-pink-200" /> 50+ Happy Clients
  //           </div>
  //           <div className="flex items-center gap-2">
  //             <Zap className="w-5 h-5 text-yellow-200" /> Fast Delivery
  //           </div>
  //           <div className="flex items-center gap-2">
  //             <Gem className="w-5 h-5 text-purple-200" /> Premium Quality
  //           </div>
  //         </div>
  //       </div>

  //       {/* Portfolio Section */}
  //       <section className="max-w-6xl mx-auto py-20 px-6 text-center">
  //         <h2 className="text-3xl font-bold mb-2 text-black">Portfolio Showcase</h2>
  //         <p className="text-lg text-gray-700 mb-8">
  //           Explore my collection of unique VTuber characters, each crafted with attention to detail and personality
  //         </p>

  //         {/* === Single-line ticker (changes every 3s) === */}
  //         <RotatingBanner />

  //         {/* === 3×3 Models Gallery === */}
  //         <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
  //           {modelImages.map((src, idx) => (
  //             <div
  //               key={idx}
  //               className="rounded-[22px] bg-white/90 p-2 shadow-md ring-1 ring-black/10"
  //             >
  //             <div className="overflow-hidden rounded-[18px] bg-neutral-200/40">
  //             <img
  //             src={src}
  //             alt={`VTuber model ${idx + 1}`}
  //             loading="lazy"
  //             className="w-full h-auto object-contain transition-transform duration-300 hover:scale-105"
  //           />
  //           </div>

  //             </div>
  //           ))}
  //         </div>
  //       </section>

  //       {/* Pricing Section */}
  //       <section className="bg-gray-50 w-full py-20 px-6 text-center">
  //         <h2 className="text-3xl font-bold mb-8">Pricing</h2>
  //         <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
  //           <Card>
  //             <CardContent className="p-6">
  //               <h3 className="font-bold text-lg mb-2">Basic</h3>
  //               <p className="text-2xl font-bold mb-4">$50</p>
  //               <ul className="mb-4 space-y-1 text-gray-700">
  //                 <li>✅ Simple Model</li>
  //                 <li>✅ Flat Colors</li>
  //                 <li>✅ 1 Expression</li>
  //               </ul>
  //               <Button>Order Now</Button>
  //             </CardContent>
  //           </Card>
  //           <Card className="border-2 border-pink-500 shadow-lg">
  //             <CardContent className="p-6">
  //               <h3 className="font-bold text-lg mb-2 text-pink-600">Standard</h3>
  //               <p className="text-2xl font-bold mb-4">$150</p>
  //               <ul className="mb-4 space-y-1 text-gray-700">
  //                 <li>✅ Detailed Model</li>
  //                 <li>✅ Shading</li>
  //                 <li>✅ 3 Expressions</li>
  //               </ul>
  //               <Button className="bg-pink-600 text-white hover:bg-pink-700">
  //                 Order Now
  //               </Button>
  //             </CardContent>
  //           </Card>
  //           <Card>
  //             <CardContent className="p-6">
  //               <h3 className="font-bold text-lg mb-2">Premium</h3>
  //               <p className="text-2xl font-bold mb-4">$300</p>
  //               <ul className="mb-4 space-y-1 text-gray-700">
  //                 <li>✅ Full Model</li>
  //                 <li>✅ Advanced Shading</li>
  //                 <li>✅ 5+ Expressions</li>
  //               </ul>
  //               <Button>Order Now</Button>
  //             </CardContent>
  //           </Card>
  //         </div>
  //       </section>

  //       {/* Contact Section */}
  //       <section className="py-20 px-6 text-center">
  //         <h2 className="text-3xl font-bold mb-4">Contact</h2>
  //         <p className="mb-6">
  //           Ready to bring your VTuber character to life? Let’s work together!
  //         </p>
  //         <Button className="bg-purple-600 text-white hover:bg-purple-700">
  //           Get in Touch
  //         </Button>
  //       </section>
  //     </main>
  //   );
  // }

// "use client";

// import { useEffect, useState } from "react";
// import { Star, Heart, Zap, Gem, Palette } from "lucide-react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import Link from "next/link";


// /* Detailed price rows for the table */
// const detailedPricing = [
//   { item: "L2D VTuber Model",        spec: "Full Body",          price: "$400" },
//   { item: "Character Design",        spec: "Full Body",          price: "$150" },
//   { item: "Complete VTuber Package", spec: "Vtubing Stuff",      price: "$450" },
//   { item: "Customize PFP",           spec: "Illustration",       price: "$100" },
//   { item: "Customize Art Scene",     spec: "Illustration",       price: "$350" },
//   { item: "Emotes 5x",               spec: "Chibi",              price: "$100" },
//   { item: "Animated Overlay Set",    spec: "Animated + Static",  price: "$150" },
//   { item: "Animated Intro",          spec: "Based on logo",      price: "$100" },
//   { item: "Model + 4 Expressions",   spec: "Full Body",          price: "$800" },
//   { item: "VTuber Intro Card",       spec: "Card",               price: "$200" },
//   { item: "Character Reference Sheet", spec: "Sheet",            price: "$150" },
// ];

// /* --- Rotating banner: switches every 2s --- */
// function RotatingBanner() {
//   const messages = [
//     "Model Art — Custom VTuber model artwork tailored to your style.",
//     "High-quality linework • Expressive designs • On-brand palettes",
//     "PSD/CLIP files • Ready for Rigging • Clean layers",
//   ];
//   const [i, setI] = useState(0);

//   useEffect(() => {
//     const id = setInterval(() => setI((p) => (p + 1) % messages.length), 2000);
//     return () => clearInterval(id);
//   }, []);

//   return (
//     <div className="w-full overflow-hidden rounded-2xl border border-black/20 shadow-lg bg-gradient-to-br from-slate-600/70 to-slate-500/70 backdrop-blur-md">
//       <div className="min-h-[64px] flex items-center justify-center px-6 py-4">
//         <span key={i} className="ticker-in text-white font-semibold text-lg text-center">
//           {messages[i]}
//         </span>
//       </div>
//     </div>
//   );
// } 

// /* Public image paths (placed in /public/models/) */
// const modelImages = [
//   "/models/2.jpeg",
//   "/models/4.jpeg",
//   "/models/3.jpeg",
//   "/models/1.png",
//   "/models/6.jpeg",
//   "/models/2d.jpg",
// ];

// export default function Home() {
//   return (
//     <main className="scroll-smooth flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
//       <div className="flex justify-center mb-6">
//         <img
//           src="/Neonola.png"
//           alt="Profile"
//           className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-white opacity-60"
//         />
//       </div>

//       <div className="text-center px-6 py-20">
//         {/* Badge */}
//         <div className="inline-block bg-white px-4 py-1 rounded-full text-sm font-bold shadow-md mb-6 text-black">
//           Welcome! <Star className="inline-block w-4 h-4 text-yellow-500 ml-1" />
//         </div>

//         {/* Heading */}
//         <h1 className="text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-6">
//           I'm Neonola, <span className="text-gray-900">VTuber Artist</span>
//         </h1>

//         {/* Subtext */}
//         <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
//           Crafting high-quality VTuber models with personality and precision.
//           Let&apos;s bring your ideal character to life in a way that captivates and connects.
//         </p>

//         {/* Buttons (now scroll to sections) */}
//         <div className="flex flex-wrap justify-center gap-4 mb-10">
//           <a
//             href="#portfolio"
//             className="px-6 py-3 rounded-lg bg-gray-900 text-white font-medium shadow hover:bg-gray-800 transition inline-flex items-center gap-2"
//           >
//             <Palette className="w-5 h-5" />
//             View Portfolio
//           </a>

//           <a
//             href="#pricing"
//             className="px-6 py-3 rounded-lg bg-white text-gray-900 font-medium shadow hover:bg-gray-100 transition inline-flex items-center gap-2"
//           >
//             <Star className="w-5 h-5" />
//             See Pricing
//           </a>
//         </div>

//         {/* Features */}
//         <div className="flex flex-wrap justify-center gap-8 text-white/90 font-medium">
//           <div className="flex items-center gap-2">
//             <Heart className="w-5 h-5 text-pink-200" /> 50+ Happy Clients
//           </div>
//           <div className="flex items-center gap-2">
//             <Zap className="w-5 h-5 text-yellow-200" /> Fast Delivery
//           </div>
//           <div className="flex items-center gap-2">
//             <Gem className="w-5 h-5 text-purple-200" /> Premium Quality
//           </div>
//         </div>
//       </div>

//       {/* Portfolio Section */}
//       <section
//         id="portfolio"
//         className="scroll-mt-24 max-w-6xl mx-auto py-20 px-6 text-center"
//         aria-label="Portfolio"
//       >
//         <h2 className="text-3xl font-bold mb-2 text-black">Portfolio Showcase</h2>
//         <p className="text-lg text-gray-700 mb-8">
//           Explore my collection of unique VTuber characters, each crafted with attention to detail and personality
//         </p>

//         {/* Single-line ticker */}
//         <RotatingBanner />

//         {/* 3×3 Models Gallery */}
//         <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
//           {modelImages.map((src, idx) => (
//             <div
//               key={idx}
//               className="rounded-[22px] bg-white/90 p-2 shadow-md ring-1 ring-black/10"
//             >
//               <div className="overflow-hidden rounded-[18px] bg-neutral-200/40">
//                 <img
//                   src={src}
//                   alt={`VTuber model ${idx + 1}`}
//                   loading="lazy"
//                   className="w-full h-auto object-contain transition-transform duration-300 hover:scale-125"
//                 />
//               </div>
//             </div>
//           ))}
//         </div>
//       </section>

//       {/* Pricing Section */}
// <section
//   id="pricing"
//   className="scroll-mt-24 bg-gray-50 w-full py-20 px-6 text-center"
//   aria-label="Pricing"
// >
//   <h2 className="text-3xl font-bold mb-8 text-black">Pricing</h2>

//   <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto items-stretch">
//     {/* Basic */}
//     <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
//       <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 via-blue-500 to-cyan-500" />
//       <div className="absolute inset-0 rounded-2xl ring-1 ring-white/20" />
//       <CardContent className="relative p-6 text-white flex flex-col justify-between">
//         <div>
//           <h3 className="font-bold text-lg mb-1">Basic</h3>
//           <p className="text-3xl font-extrabold mb-6">$100</p>

//           <ul className="space-y-3 text-white/95 text-left">
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>Character Design</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>Flat Colors</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>1 Expression</span>
//             </li>
//           </ul>
//         </div>

//         <Button className="mt-6 w-full rounded-xl bg-white text-black hover:text-black hover:bg-white/90 shadow">
//   Order Now
// </Button>

//       </CardContent>
//     </Card>

//     {/* Standard (featured) */}
//     <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
//       <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-500 via-pink-500 to-rose-500" />
//       <div className="absolute inset-0 rounded-2xl ring-2 ring-rose-200/60" />
//       <CardContent className="relative p-6 text-white flex flex-col justify-between">
//         <div>
//           <h3 className="font-bold text-lg mb-1 drop-shadow">Standard</h3>
//           <p className="text-3xl font-extrabold mb-6">$300</p>

//           <ul className="space-y-3 text-white/95 text-left">
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>Live2D VTuber Model</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>Full Body + Rigging</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>3 Expressions</span>
//             </li>
//           </ul>
//         </div>

//         <Button className="mt-6 w-full rounded-xl bg-white/15 hover:bg-white/25 text-white backdrop-blur shadow">
//           Order Now
//         </Button>
//       </CardContent>  
//     </Card>

//     {/* Premium */}
//     <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
//       <div className="absolute inset-0 bg-gradient-to-br from-amber-500 via-orange-500 to-red-500" />
//       <div className="absolute inset-0 rounded-2xl ring-1 ring-white/20" />
//       <CardContent className="relative p-6 text-white flex flex-col justify-between">
//         <div>
//           <h3 className="font-bold text-lg mb-1">Premium</h3>
//           <p className="text-3xl font-extrabold mb-6">$550</p>

//           <ul className="space-y-3 text-white/95 text-left">
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>3D Model</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>Full Body</span>
//             </li>
//             <li className="flex items-center gap-3">
//               <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
//               <span>5+ Expressions</span>
//             </li>
//           </ul>
//         </div>

//         <Button className="mt-6 w-full rounded-xl bg-white text-black hover:text-black hover:bg-white/90 shadow">
//   Order Now
// </Button>

//       </CardContent>
//     </Card>

//     {/* ===== Detailed Pricing List (under cards) ===== */}
// {/* ===== Detailed Pricing List (full-width & centered) ===== */}
// <div className="mt-16 flex justify-center w-full px-4 sm:px-6 lg:px-">
//   <div className="w-full max-w-5xl">
//     <div className="rounded-2xl bg-sky-100/70 ring-1 ring-sky-200 shadow">
//       {/* Heading */}
//       <div className="px-6 pt-6 pb-4 text-center">
//         <h3 className="text-3xl font-extrabold tracking-widest text-black">
//           PRICING
//         </h3>
//         <div className="mt-3 h-[2px] w-full bg-black/70" />
//       </div>

//       {/* Table */}
//       <div className="overflow-x-auto">
//         <table className="w-full table-fixed text-left text-gray-800/95">
//           {/* control column widths so everything lines up nicely */}
//           <colgroup>
//             <col className="w-[48%]" />
//             <col className="w-[32%]" />
//             <col className="w-[20%]" />
//           </colgroup>
//           <tbody>
//             {detailedPricing.map((row, i) => (
//               <tr
//                 key={i}
//                 className="border-t border-sky-200/80 hover:bg-white/40 transition"
//               >
//                 <td className="p-4 md:p-5 font-semibold">{row.item}</td>
//                 <td className="p-4 md:p-5">{row.spec}</td>
//                 <td className="p-4 md:p-5 text-right font-bold">{row.price}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       </div>
//     </div>

//     {/* Includes */}
//     <div className="mt-8 text-left max-w-3xl mx-auto">
//       <h4 className="font-semibold text-black mb-2">VTuber Package Includes :</h4>
//       <ul className="list-disc pl-6 space-y-1 text-gray-800/90">
//         <li>1× Custom Logo</li>
//         <li>2× Banners (Twitch & YouTube or other socials)</li>
//         <li>Source files (PSD/CLIP) + export PNGs</li>
//         <li>Commercial-use rights (optional add-on)</li>
//       </ul>
//     </div>
//   </div>
// </div>


//   </div>
// </section>


//       {/* Contact Section */}
//       <section
//         id="contact"
//         className="scroll-mt-24 py-20 px-6 text-center"
//         aria-label="Contact"
//       >
//         <h2 className="text-3xl font-bold mb-4">Contact</h2>
//         <p className="mb-6">
//           Ready to bring your VTuber character to life? Let’s work together!
//         </p>
//         <Button className="bg-purple-600 text-white hover:bg-purple-700">
//           Get in Touch
//         </Button>
//       </section>
//     </main>
//   );
// }



"use client";

import { useEffect, useState } from "react";
import { Star, Heart, Zap, Gem, Palette } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

/* Detailed price rows for the table */
const detailedPricing = [
  { item: "Complete VTuber Package", spec: "Vtubing Stuff",      price: "$400" },
  { item: "Customize Art Scene",     spec: "Illustration",       price: "$300" },
  { item: "L2D VTuber Model",        spec: "Full Body",          price: "$250" },
  { item: "Animated Overlay Set",    spec: "Animated + Static",  price: "$150" },
  { item: "VTuber Intro Card",       spec: "Card",               price: "$140" },
  { item: "Character Reference Sheet", spec: "Sheet",            price: "$120" },
  { item: "Animated Intro",          spec: "Based on logo",      price: "$90" },
  { item: "Emotes 5x",               spec: "Chibi",              price: "$80" },
  { item: "Customize PFP",           spec: "Illustration",       price: "$70" },
  { item: "Model + 4 Expressions",   spec: "Full Body",          price: "$600" },
  
  
];

/* --- Rotating banner: switches every 2s --- */
function RotatingBanner() {
  const messages = [
    "Model Art — Custom VTuber model artwork tailored to your style.",
    "High-quality linework • Expressive designs • On-brand palettes",
    "PSD/CLIP files • Ready for Rigging • Clean layers",
  ];
  const [i, setI] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setI((p) => (p + 1) % messages.length), 2000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="w-full overflow-hidden rounded-2xl border border-black/20 shadow-lg bg-gradient-to-br from-slate-600/70 to-slate-500/70 backdrop-blur-md">
      <div className="min-h-[64px] flex items-center justify-center px-6 py-4">
        <span key={i} className="ticker-in text-white font-semibold text-lg text-center">
          {messages[i]}
        </span>
      </div>
    </div>
  );
}

/* Public image paths (placed in /public/models/) */
const modelImages = [
  "/models/2.jpeg",
  "/models/4.jpeg",
  "/models/3.jpeg",
  "/models/1.png",
  "/models/6.jpeg",
  "/models/2d.jpg",
];

export default function Home() {
  return (
    <main className="scroll-smooth flex min-h-screen flex-col items-center justify-center bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
      <div className="flex justify-center mb-6">
        <img
          src="/Neonola.png"
          alt="Profile"
          className="w-32 h-32 rounded-full object-cover shadow-lg border-4 border-white opacity-60"
        />
      </div>

      <div className="text-center px-6 py-20">
        {/* Badge */}
        <div className="inline-block bg-white px-4 py-1 rounded-full text-sm font-bold shadow-md mb-6 text-black">
          Welcome! <Star className="inline-block w-4 h-4 text-yellow-500 ml-1" />
        </div>

        {/* Heading */}
        <h1 className="text-5xl md:text-6xl font-extrabold text-white drop-shadow-lg mb-6">
          I'm Neonola, <span className="text-gray-900">VTuber Artist</span>
        </h1>

        {/* Subtext */}
        <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-8">
          Crafting high-quality VTuber models with personality and precision.
          Let&apos;s bring your ideal character to life in a way that captivates and connects.
        </p>

        {/* Buttons */}
        <div className="flex flex-wrap justify-center gap-4 mb-10">
          <a
            href="#portfolio"
            className="px-6 py-3 rounded-lg bg-gray-900 text-white font-medium shadow hover:bg-gray-800 transition inline-flex items-center gap-2"
          >
            <Palette className="w-5 h-5" />
            View Portfolio
          </a>

          <a
            href="#pricing"
            className="px-6 py-3 rounded-lg bg-white text-gray-900 font-medium shadow hover:bg-gray-100 transition inline-flex items-center gap-2"
          >
            <Star className="w-5 h-5" />
            See Pricing
          </a>
        </div>

        {/* Features */}
        <div className="flex flex-wrap justify-center gap-8 text-white/90 font-medium">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-200" /> 50+ Happy Clients
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-200" /> Fast Delivery
          </div>
          <div className="flex items-center gap-2">
            <Gem className="w-5 h-5 text-purple-200" /> Premium Quality
          </div>
        </div>
      </div>

      {/* Portfolio Section */}
      <section
        id="portfolio"
        className="scroll-mt-24 max-w-6xl mx-auto py-20 px-6 text-center"
        aria-label="Portfolio"
      >
        <h2 className="text-3xl font-bold mb-2 text-black">Portfolio Showcase</h2>
        <p className="text-lg text-gray-700 mb-8">
          Explore my collection of unique VTuber characters, each crafted with attention to detail and personality
        </p>

        {/* Rotating banner */}
        <RotatingBanner />

        {/* Models Gallery */}
        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {modelImages.map((src, idx) => (
            <div
              key={idx}
              className="rounded-[22px] bg-white/90 p-2 shadow-md ring-1 ring-black/10"
            >
              <div className="overflow-hidden rounded-[18px] bg-neutral-200/40">
                <img
                  src={src}
                  alt={`VTuber model ${idx + 1}`}
                  loading="lazy"
                  className="w-full h-auto object-contain transition-transform duration-300 hover:scale-125"
                />
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Section */}
      <section
        id="pricing"
        className="scroll-mt-24 bg-gray-50 w-full py-20 px-6 text-center"
        aria-label="Pricing"
      >
        <h2 className="text-3xl font-bold mb-8 text-black">Sale (Package)</h2>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto items-stretch">
          {/* Basic */}
          <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-br from-indigo-500 via-blue-500 to-cyan-500" />
            <div className="absolute inset-0 rounded-2xl ring-1 ring-white/20" />
            <CardContent className="relative p-6 text-white flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg mb-1">Basic</h3>
                <p className="text-3xl font-extrabold mb-6">$100</p>

                <ul className="space-y-3 text-white/95 text-left">
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>Character Design</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>Flat Colors</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>1 Expression</span>
                  </li>
                </ul>
              </div>

              <Button className="mt-6 w-full rounded-xl bg-white text-black hover:text-black hover:bg-white/90 shadow">
                Order Now
              </Button>
            </CardContent>
          </Card>

          {/* Standard */}
          <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-br from-fuchsia-500 via-pink-500 to-rose-500" />
            <div className="absolute inset-0 rounded-2xl ring-2 ring-rose-200/60" />
            <CardContent className="relative p-6 text-white flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg mb-1 drop-shadow">Standard</h3>
                <p className="text-3xl font-extrabold mb-6">$300</p>

                <ul className="space-y-3 text-white/95 text-left">
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>Live2D VTuber Model</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>Full Body + Rigging</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>3 Expressions</span>
                  </li>
                </ul>
              </div>

              <Button className="mt-6 w-full rounded-xl bg-white/15 hover:bg-white/25 text-white backdrop-blur shadow">
                Order Now
              </Button>
            </CardContent>
          </Card>

          {/* Premium */}
          <Card className="relative overflow-hidden rounded-2xl border-0 shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500 via-orange-500 to-red-500" />
            <div className="absolute inset-0 rounded-2xl ring-1 ring-white/20" />
            <CardContent className="relative p-6 text-white flex flex-col justify-between">
              <div>
                <h3 className="font-bold text-lg mb-1">Premium</h3>
                <p className="text-3xl font-extrabold mb-6">$550</p>

                <ul className="space-y-3 text-white/95 text-left">
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>3D Model</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>Full Body</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <span className="inline-flex h-5 w-5 items-center justify-center rounded-md bg-emerald-500 text-white text-xs font-bold shadow">✓</span>
                    <span>5+ Expressions</span>
                  </li>
                </ul>
              </div>

              <Button className="mt-6 w-full rounded-xl bg-white text-black hover:text-black hover:bg-white/90 shadow">
                Order Now
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* ===== Detailed Pricing List (full-width & centered) ===== */}
        <div className="mt-16 flex justify-center w-full px-4 sm:px-6">
          <div className="w-full max-w-5xl">
            <div className="rounded-2xl bg-sky-100/70 ring-1 ring-sky-200 shadow">
              {/* Heading */}
              <div className="px-6 pt-6 pb-4 text-center">
                <h3 className="text-3xl font-extrabold tracking-widest text-black">
                  PRICING
                </h3>
                <div className="mt-3 h-[2px] w-full bg-black/70" />
              </div>

              {/* Table */}
              <div className="overflow-x-auto">
                <table className="w-full table-fixed text-left text-gray-800/95">
                  <colgroup>
                    <col className="w-[48%]" />
                    <col className="w-[32%]" />
                    <col className="w-[20%]" />
                  </colgroup>
                  <tbody>
                    {detailedPricing.map((row, i) => (
                      <tr
                        key={i}
                        className="border-t border-sky-200/80 hover:bg-white/40 transition"
                      >
                        <td className="p-4 md:p-5 font-semibold">{row.item}</td>
                        <td className="p-4 md:p-5">{row.spec}</td>
                        <td className="p-4 md:p-5 text-right font-bold">{row.price}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Includes */}
            <div className="mt-8 text-center max-w-3xl mx-auto">
              <h4 className="font-semibold text-black mb-2">VTuber Package Includes :</h4>
              <ul className="list-disc pl-6 space-y-1 text-gray-800/90">
              <p>1× Custom Logo</p>
              <p>2× Banners (Twitch & YouTube or other socials)</p>
              <p>Source files (PSD/CLIP) + export PNGs</p>
              <p>1x Animated Intro</p>
              <p>1x Animated outro</p>
              <p>1x Animated Overlay set</p>
              <p>4x Emotes</p>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section
        id="contact"
        className="scroll-mt-24 py-20 px-6 text-center"
        aria-label="Contact"
      >
        <h2 className="text-3xl font-bold mb-4">Contact</h2>
        <p className="mb-6">
          Ready to bring your VTuber character to life? Let’s work together!
        </p>
        <Button className="bg-purple-600 text-white hover:bg-purple-700">
          Get in Touch
        </Button>
      </section>
    </main>
  );
}
