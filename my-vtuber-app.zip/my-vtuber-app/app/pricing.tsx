// app/pricing/page.tsx
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";

export const metadata = {
  title: "Pricing — Neonola VTuber Artist",
  description:
    "VTuber model art & rigging packages with clear, transparent pricing.",
};

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-pink-300 via-blue-300 to-purple-300">
      <header className="mx-auto max-w-5xl px-6 pt-12 pb-6 flex items-center justify-between">
        <h1 className="text-3xl md:text-4xl font-extrabold text-black drop-shadow-sm">
          Pricing
        </h1>

        <div className="flex gap-3">
          <Link
            href="/"
            className="rounded-lg px-4 py-2 bg-white/90 text-gray-900 shadow hover:bg-white transition"
          >
            ← Home
          </Link>
          <Link
            href="/#contact"
            className="rounded-lg px-4 py-2 bg-purple-600 text-white shadow hover:bg-purple-700 transition"
          >
            Contact
          </Link>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-6 pb-16">
        <p className="text-center text-gray-800/90 max-w-2xl mx-auto mb-10">
          Choose the package that fits your project. Every order includes clear
          communication, source files, and minor revisions.
        </p>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Basic */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold text-lg mb-2">Basic</h3>
              <p className="text-2xl font-bold mb-4">$50</p>
              <ul className="mb-4 space-y-1 text-gray-700">
                <li>✅ Simple Model</li>
                <li>✅ Flat Colors</li>
                <li>✅ 1 Expression</li>
              </ul>
              <Link href="/#contact">
                <Button className="w-full">Order Now</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Standard (featured) */}
          <Card className="border-2 border-pink-500 shadow-lg">
            <CardContent className="p-6">
              <h3 className="font-bold text-lg mb-2 text-pink-600">Standard</h3>
              <p className="text-2xl font-bold mb-4">$150</p>
              <ul className="mb-4 space-y-1 text-gray-700">
                <li>✅ Detailed Model</li>
                <li>✅ Shading</li>
                <li>✅ 3 Expressions</li>
              </ul>
              <Link href="/#contact">
                <Button className="w-full bg-pink-600 text-white hover:bg-pink-700">
                  Order Now
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Premium */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-bold text-lg mb-2">Premium</h3>
              <p className="text-2xl font-bold mb-4">$300</p>
              <ul className="mb-4 space-y-1 text-gray-700">
                <li>✅ Full Model</li>
                <li>✅ Advanced Shading</li>
                <li>✅ 5+ Expressions</li>
              </ul>
              <Link href="/#contact">
                <Button className="w-full">Order Now</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <p className="text-center text-sm text-gray-800/70 mt-8">
          Need something custom?{" "}
          <Link href="/#contact" className="underline font-medium">
            Get in touch
          </Link>{" "}
          for a tailored quote.
        </p>
      </section>
    </main>
  );
}
