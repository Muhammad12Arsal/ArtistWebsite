import * as React from "react";
import { cn } from "@/lib/utils";

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline";
  size?: "sm" | "lg";
}

export function Button({
  className,
  variant = "default",
  size = "sm",
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        "rounded-xl font-medium transition-all",
        variant === "default"
          ? "bg-purple-600 text-white hover:bg-purple-700"
          : "border border-purple-600 text-purple-400 hover:bg-purple-600/10",
        size === "sm" ? "px-4 py-2 text-sm" : "px-8 py-4 text-lg",
        className
      )}
      {...props}
    />
  );
}
