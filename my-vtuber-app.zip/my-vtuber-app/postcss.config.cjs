// // postcss.config.mjs
// import tailwindcss from "@tailwindcss/postcss";
// import autoprefixer from "autoprefixer";

// /** @type {import('postcss-load-config').Config} */
// export default {
//   plugins: {
//     [tailwindcss]: {},
//     [autoprefixer]: {},
//   },
// };
// postcss.config.cjs
module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
};
